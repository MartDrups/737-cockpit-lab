'use strict';
(() => {
const lesson=window.CBT_LESSON;
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const storeKey='737-cbt-intro-viewed';
let container;
function viewed(){try{return localStorage.getItem(storeKey)==='yes';}catch{return false;}}
function render(target){
 container=target;
 const done=viewed();
 target.innerHTML=`<section class="cbt-intro"><span class="cbt-section-tag">ОБУЧЕНИЕ · 01</span><h2>Учимся работать с CBT</h2><p>Оригинальные уроки из предоставленного учебного комплекта Boeing 737. Начните со знакомства с управлением и заданиями.</p></section><article class="cbt-lesson-card"><div class="cbt-lesson-mark" aria-hidden="true">01<span>CBT</span></div><div class="cbt-lesson-body"><div class="cbt-lesson-meta"><span>≈ ${lesson.minutes} мин</span><span>${esc(lesson.language)}</span><span class="cbt-viewed" ${done?'':'hidden'}>Отмечен как пройденный</span></div><h2>${esc(lesson.title)}</h2><p class="cbt-original-title">${esc(lesson.originalTitle)}</p><p>${esc(lesson.description)}</p><div class="cbt-card-actions"><button class="cbt-primary" data-cbt-open>Открыть урок <span aria-hidden="true">→</span></button><span>Все материалы урока — около ${Math.ceil(lesson.downloadBytes/1e6)} МБ</span></div></div></article><details class="cbt-contents"><summary>Что входит в урок</summary><ol>${lesson.topics.map(t=>`<li>${esc(t)}</li>`).join('')}</ol></details><div class="cbt-notes"><div><h3>Без интернета</h3><p>В окне «Приложение» скачайте все материалы и дождитесь «Всё сохранено». Урок сохранится вместе с кабиной.</p></div><div><h3>Об учебном комплекте</h3><p>${esc(lesson.source)}. Это отдельный исторический курс. Действующий источник нашего справочника — FCOM S7 от 15 ноября 2021 года.</p></div></div>`;
 target.querySelector('[data-cbt-open]').addEventListener('click',open);
}
function open(){
 container.innerHTML=`<section class="cbt-lesson-head"><button data-cbt-back class="cbt-back">← К урокам</button><div><h2>${esc(lesson.title)}</h2><p>${esc(lesson.originalTitle)} · ≈ ${lesson.minutes} мин</p></div></section><div class="cbt-player-shell"><iframe src="cbt/player.html" title="Оригинальный вводный урок CBT" allow="autoplay; fullscreen" allowfullscreen></iframe></div><details class="cbt-help"><summary>Как пройти урок</summary><p>Нажмите «Начать урок»: озвучка включится от этого нажатия. Урок продолжает пояснения автоматически и ждёт ваших действий в упражнениях.</p><p>Слушайте оригинальную озвучку и выполняйте инструкции. На сцене можно нажимать показанные органы; те же действия доступны крупными кнопками ниже. «Продолжить» работает там, где оригинал ждёт зелёную стрелку. Доступны пауза, повтор, звук, текст, глоссарий и заметки.</p><p>На телефоне используйте альбомную ориентацию. Кнопки масштаба увеличивают экран; увеличенную сцену можно прокручивать. «На весь экран» освобождает место для урока.</p></details><div class="cbt-finish"><label><input type="checkbox" data-cbt-viewed ${viewed()?'checked':''}> Я прошёл урок</label><p>Эта отметка сохраняется на вашем устройстве.</p></div>`;
 container.querySelector('[data-cbt-back]').addEventListener('click',()=>render(container));
 container.querySelector('[data-cbt-viewed]').addEventListener('change',e=>{try{localStorage.setItem(storeKey,e.target.checked?'yes':'no');}catch{}});
}
window.CBTView={render,close:()=>{container?.querySelector('iframe')?.remove();}};
window.addEventListener('message',event=>{
 const frame=container?.querySelector('iframe');
 if(event.origin!==location.origin||event.source!==frame?.contentWindow||event.data?.type!=='CBT_LESSON_COMPLETE')return;
 try{localStorage.setItem(storeKey,'yes');}catch{}
 const mark=container.querySelector('[data-cbt-viewed]');if(mark)mark.checked=true;
});
})();
