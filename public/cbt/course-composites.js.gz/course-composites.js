'use strict';
(() => {
 const images=new Map(),sheets=new Map();
 function image(file){if(!images.has(file))images.set(file,new Promise((resolve,reject)=>{const i=new Image();i.onload=()=>resolve(i);i.onerror=()=>reject(new Error('Source image unavailable'));i.src=file}));return images.get(file)}
 async function graphic(actor,url){
  if(!actor.symbol)return image(url(actor.file));
  const file=url(actor.file);if(!sheets.has(file))sheets.set(file,fetch(file).then(r=>{if(!r.ok)throw new Error('Source SVG unavailable');return r.text()}).then(t=>new DOMParser().parseFromString(t,'image/svg+xml')));
  const doc=await sheets.get(file),symbol=doc.getElementById(actor.symbol);if(!symbol)throw new Error('Source symbol absent');
  const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('xmlns','http://www.w3.org/2000/svg');svg.setAttribute('viewBox',actor.viewBox);svg.setAttribute('width',actor.rect.w);svg.setAttribute('height',actor.rect.h);svg.setAttribute('preserveAspectRatio','none');
  [...symbol.children].forEach(c=>svg.append(c.cloneNode(true)));
  return image('data:image/svg+xml;charset=utf-8,'+encodeURIComponent(new XMLSerializer().serializeToString(svg)));
 }
 async function create(canvas,actor,url,stage){
  const preceding=[...stage.children].slice(0,[...stage.children].indexOf(canvas));
  canvas.width=actor.rect.w;canvas.height=actor.rect.h;const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.imageSmoothingEnabled=false;
  ctx.fillStyle=getComputedStyle(document.getElementById('stage')).backgroundColor;ctx.fillRect(0,0,canvas.width,canvas.height);
  for(const element of preceding){
   await element._renderReady;
   const a=element._sourceActor;if(!a)continue;
   const style=getComputedStyle(element),x=parseFloat(style.left)-actor.rect.x,y=parseFloat(style.top)-actor.rect.y;
   const source=element.tagName==='CANVAS'?element:await graphic(a,url);
   ctx.drawImage(source,x,y,a.rect.w,a.rect.h);
  }
  for(const layer of actor.composition){
   const operand=await image(url(layer.file));
   if(layer.kind==='svg'){ctx.drawImage(operand,0,0,canvas.width,canvas.height);continue}
   if(layer.kind!=='xnor'||layer.sourceROP3!=='0x990066')throw new Error('Unknown source composition');
   const r=layer.destRect,b=actor.sourceBounds,x=r.x-b.x,y=r.y-b.y;
   const scratch=document.createElement('canvas');scratch.width=r.width;scratch.height=r.height;const s=scratch.getContext('2d',{willReadFrequently:true});s.imageSmoothingEnabled=false;s.drawImage(operand,0,0,r.width,r.height);
   const src=s.getImageData(0,0,r.width,r.height).data,dst=ctx.getImageData(0,0,canvas.width,canvas.height);
   for(let sy=0;sy<r.height;sy++)for(let sx=0;sx<r.width;sx++){
    const dx=x+sx,dy=y+sy;if(dx<0||dy<0||dx>=canvas.width||dy>=canvas.height)continue;
    const a=(sy*r.width+sx)*4,d=(dy*canvas.width+dx)*4;
    if(!src[a+3])continue;if(src[a+3]!==255)throw new Error('Unproved source ROP alpha');
    for(let c=0;c<3;c++)dst.data[d+c]=(~(dst.data[d+c]^src[a+c]))&255;dst.data[d+3]=255;
   }
   ctx.putImageData(dst,0,0);
  }
  canvas.dataset.sourceComposition='ready';
 }
 window.CBTComposite={create};
})();
