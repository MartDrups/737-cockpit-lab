'use strict';
/* Original lossless movie frames; source subsets and reverse playback share atlases. */
window.CBTMovie = (() => {
 const images = new Map();
 function bitmap(file, url) {
  if (!images.has(file)) images.set(file, new Promise((resolve, reject) => {
   const image = new Image();
   image.onload = () => resolve(image);
   image.onerror = () => { images.delete(file); reject(new Error('Animation atlas unavailable')); };
   image.src = url(file);
  }));
  return images.get(file);
 }
 function create(canvas, movie, url, fail, initial) {
  canvas.width = movie.width; canvas.height = movie.height;
  const context = canvas.getContext('2d');
  context.imageSmoothingEnabled = false;
  const first = movie.firstFrame ?? (initial?.frame >= 0 ? initial.frame : null), last = movie.lastFrame ?? first;
  const direction = last >= first ? 1 : -1, count = Math.abs(last - first) + 1;
  const fps = movie.exactParameters ? movie.fps : 0;
  let elapsed = Math.max(0, initial?.elapsed || 0), resumed = performance.now(), paused = false, stopped = false;
  let frame = -1, generation = 0, request = 0;
  function draw(index) {
   const atlas = movie.atlases.find(a => index >= a.startFrame && index < a.startFrame + a.frameCount);
   if (!atlas) { fail(); return; }
   const current = ++generation;
   bitmap(atlas.file, url).then(image => {
    if (stopped || current !== generation) return;
    const offset = index - atlas.startFrame;
    context.clearRect(0, 0, movie.width, movie.height);
    context.drawImage(image, offset % atlas.columns * movie.width, Math.floor(offset / atlas.columns) * movie.height,
     movie.width, movie.height, 0, 0, movie.width, movie.height);
   }).catch(() => { if (!stopped) fail(); });
  }
  function tick() {
   if (paused || stopped) return;
   // An unresolved parameter cannot manufacture a frame number. Keep a
   // previously displayed source frame, or leave an unknown initial view empty.
   if (first === null) return;
   const seconds = (elapsed + performance.now() - resumed) / 1000;
   const step = Math.floor(seconds * fps);
   const loops = movie.loopCount;
   const finished = !fps || (loops > 0 && step >= count * loops);
   const index = finished ? (fps ? last : first) : first + direction * (step % count);
   if (index !== frame) { frame = index; draw(index); }
   if (!finished) request = requestAnimationFrame(tick);
  }
  tick();
  return {
   pause() { if (paused || stopped) return; elapsed += performance.now() - resumed; paused = true; cancelAnimationFrame(request); },
   resume() { if (!paused || stopped) return; paused = false; resumed = performance.now(); tick(); },
   stop() { stopped = true; generation++; cancelAnimationFrame(request); },
   get frame() { return frame; },
   get snapshot() { return {elapsed:elapsed + (paused || stopped ? 0 : performance.now() - resumed),frame}; }
  };
 }
 return {create};
})();
