'use strict';
(() => {
  const $ = selector => document.querySelector(selector);
  const dialog = $('#pwa-dialog');
  const installedQuery = matchMedia('(display-mode: standalone)');
  let installedHere = false;
  const isInstalled = () => installedHere || installedQuery.matches || navigator.standalone === true;
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1;
  const supported = 'serviceWorker' in navigator && window.isSecureContext;
  let registration, installPrompt, applyingUpdate = false;
  let state = null, failure = '', pending = false;
  let settingUp = false;
  let checkingUpdate = false, updateStatus = '', lastUpdateCheck = 0;
  const mb = bytes => (bytes / 1048576).toLocaleString('ru', {maximumFractionDigits: 1}) + ' МБ';

  function instructions() {
    $('#pwa-install-status').textContent = isInstalled() ?
      (installedHere ? 'Приложение установлено. Откройте его значком на главном экране.' :
        'Вы открыли установленное приложение.') :
      'Добавьте значок на главный экран, чтобы открывать кабину как приложение.';
    $('#pwa-install').hidden = isInstalled();
    $('#pwa-install').textContent = installPrompt ? 'Установить приложение' : 'Как установить';
    $('#pwa-install-guide').textContent = isIOS ?
      'На iPhone или iPad откройте сайт в Safari → «Поделиться» → «На экран „Домой“» → «Добавить». Затем откройте приложение с главного экрана и скачайте материалы внутри него.' :
      /Android/.test(navigator.userAgent) ?
      'В Chrome на Android откройте меню ⋮ → «Установить приложение» или «Добавить на главный экран». После установки откройте приложение и скачайте материалы.' :
      'В Chrome или Edge нажмите значок установки в адресной строке или выберите «Установить приложение» в меню браузера.';
  }
  function render() {
    instructions();
    const ready = !!state?.ready;
    const downloading = !!state?.downloading;
    const offline = !navigator.onLine;
    $('#pwa-btn').classList.toggle('offline-ready', ready);
    $('#pwa-btn').classList.toggle('no-connection', offline);
    $('#pwa-btn').title = offline ? (ready ? 'Нет интернета · материалы сохранены' :
      'Нет интернета · материалы скачаны не полностью') :
      ready ? 'Приложение · все материалы сохранены' : 'Установка и офлайн-режим';
    $('#pwa-network').hidden = !offline;
    $('#pwa-network').textContent = ready ?
      'Нет интернета. Кабина, схемы и страницы FCOM доступны.' :
      'Нет интернета. Можно открыть только уже сохранённые материалы.';
    $('#pwa-error').hidden = !failure;
    $('#pwa-error').textContent = failure;
    $('#pwa-progress').hidden = !state;
    $('#pwa-progress').max = state?.totalBytes || 1;
    $('#pwa-progress').value = state?.bytes || 0;
    const status = $('#pwa-offline-status');
    if (!supported) {
      status.textContent = 'Для офлайн-режима откройте сайт по защищённой ссылке (HTTPS) в современном браузере.';
    } else if (!state) {
      status.textContent = failure ? 'Подготовка не завершена.' : 'Подготавливаем загрузку…';
    } else if (ready) {
      status.textContent = 'Всё сохранено · справочник и вводный CBT · ' + mb(state.totalBytes);
    } else {
      status.textContent = (downloading ? 'Скачиваем: ' : 'Сохранено: ') +
        mb(state.bytes) + ' из ' + mb(state.totalBytes);
    }
    status.classList.toggle('ready', ready);
    $('#pwa-download-note').hidden = !downloading;
    $('#pwa-download').hidden = ready || !supported;
    $('#pwa-download').disabled = !state || pending || offline || downloading;
    $('#pwa-download').textContent = state?.materialCount > 0 ?
      'Продолжить загрузку' : 'Скачать справочник и вводный CBT';
    $('#pwa-pause').hidden = !downloading;
    $('#pwa-clear').hidden = !state?.materialCount;
    $('#pwa-clear').disabled = pending || downloading;
    $('#pwa-update').hidden = !registration?.waiting;
    $('#pwa-apply-update').disabled = applyingUpdate;
    $('#pwa-check-update').hidden = !supported;
    $('#pwa-check-update').disabled = checkingUpdate || settingUp || offline;
    $('#pwa-update-status').textContent = registration?.waiting ?
      'Новая версия готова. Нажмите «Обновить приложение».' :
      registration?.installing ? 'Подготавливаем новую версию…' : updateStatus;
    const retry = $('#pwa-retry');
    if (retry) {
      retry.hidden = !supported || !!state || !failure;
      retry.disabled = settingUp || pending || offline;
    }
  }
  function request(type, worker = registration?.active) {
    return new Promise((resolve, reject) => {
      if (!worker) { reject(new Error('Подготовка ещё идёт. Попробуйте через несколько секунд.')); return; }
      const channel = new MessageChannel();
      const timeout = setTimeout(() => {
        channel.port1.close();
        reject(new Error('Приложение не ответило. Закройте это окно и откройте его снова.'));
      }, 20000);
      channel.port1.onmessage = event => {
        clearTimeout(timeout);
        channel.port1.close();
        event.data.error ? reject(new Error(event.data.message)) : resolve(event.data);
      };
      worker.postMessage({type}, [channel.port2]);
    });
  }
  async function refresh() {
    if (!registration?.active) return;
    try { const result = await request('GET_STATUS'); state = result.status; render(); }
    catch (error) { failure = error.message; render(); }
  }
  async function checkUpdate(force = false) {
    if (!supported || !navigator.onLine || checkingUpdate || settingUp ||
        (!force && Date.now() - lastUpdateCheck < 60000)) return;
    checkingUpdate = true;
    lastUpdateCheck = Date.now();
    updateStatus = 'Проверяем обновления…';
    render();
    try {
      if (!registration) await setup();
      if (!registration) throw new Error('Регистрация приложения не завершена.');
      await registration.update();
      updateStatus = registration.installing ? 'Подготавливаем новую версию…' :
        registration.waiting ? '' : 'Установлена последняя версия.';
    } catch {
      updateStatus = 'Не удалось проверить обновление. Проверьте интернет и повторите.';
    } finally { checkingUpdate = false; render(); }
  }
  $('#pwa-btn').addEventListener('click', () => {
    dialog.showModal();
    render();
    if (registration?.active) refresh();
    else if (supported && navigator.onLine) setup();
    checkUpdate(true);
  });
  $('#pwa-check-update').addEventListener('click', () => checkUpdate(true));
  $('#pwa-close').addEventListener('click', () => dialog.close());
  $('#pwa-retry')?.addEventListener('click', () => {
    failure = '';
    setup(true);
  });
  dialog.addEventListener('click', event => {
    if (event.target !== dialog) return;
    const r = dialog.getBoundingClientRect();
    if (event.clientX < r.left || event.clientX > r.right ||
        event.clientY < r.top || event.clientY > r.bottom) dialog.close();
  });
  $('#pwa-install').addEventListener('click', async () => {
    if (!installPrompt) {
      $('#pwa-install-guide').hidden = false;
      return;
    }
    const prompt = installPrompt;
    installPrompt = null;
    try { await prompt.prompt(); await prompt.userChoice; }
    catch { $('#pwa-install-guide').hidden = false; }
    render();
  });
  $('#pwa-download').addEventListener('click', async () => {
    pending = true; failure = ''; render();
    try {
      // Best effort: the browser remains in charge of device storage.
      navigator.storage?.persist?.().catch(() => {});
      const estimate = await navigator.storage?.estimate?.();
      const remaining = state.totalBytes - state.bytes;
      if (estimate?.quota && estimate.quota - estimate.usage < remaining) {
        throw new Error('Для всех материалов не хватает места. Освободите место на устройстве и повторите загрузку.');
      }
      await request('DOWNLOAD');
      state.downloading = true;
    } catch (error) { failure = error.message; }
    finally { pending = false; render(); }
  });
  $('#pwa-pause').addEventListener('click', async () => {
    try { await request('PAUSE'); }
    catch (error) { failure = error.message; render(); }
  });
  $('#pwa-clear').addEventListener('click', async () => {
    pending = true; render();
    try { state = (await request('CLEAR')).status; failure = ''; }
    catch (error) { failure = error.message; }
    finally { pending = false; render(); }
  });
  $('#pwa-apply-update').addEventListener('click', async () => {
    if (!registration?.waiting) return;
    applyingUpdate = true;
    $('#pwa-apply-update').disabled = true;
    try { await request('SKIP_WAITING', registration.waiting); }
    catch (error) { applyingUpdate = false; failure = error.message; render(); }
  });
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault(); installPrompt = event; render();
  });
  window.addEventListener('appinstalled', () => {
    installedHere = true; installPrompt = null; $('#pwa-install-guide').hidden = true; render();
  });
  installedQuery.addEventListener('change', render);
  window.addEventListener('online', () => {
    failure = ''; render(); refresh();
    if (!registration && supported) setup();
    else checkUpdate();
  });
  window.addEventListener('offline', render);
  window.addEventListener('pageshow', () => checkUpdate());
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') checkUpdate();
  });
  if (supported) {
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (applyingUpdate) location.reload();
      else refresh();
    });
    navigator.serviceWorker.addEventListener('message', event => {
      const data = event.data;
      if (data?.type === 'OFFLINE_SETUP_ERROR') {
        updateStatus = 'Подготовка обновления прервалась. Проверьте интернет и нажмите «Проверить обновление».';
        if (!registration?.active) {
          failure = data.code === 'storage' ?
            'Не удалось сохранить файлы приложения. Освободите место на устройстве и нажмите «Повторить подготовку».' :
            data.code === 'auth' ?
            'Не удалось получить страницу приложения. Проверьте, что сайт открывается с интернетом, и нажмите «Повторить подготовку».' :
            'Не удалось скачать файлы приложения. Проверьте интернет и нажмите «Повторить подготовку».';
        }
        render();
        return;
      }
      if (!['OFFLINE_PROGRESS', 'OFFLINE_COMPLETE', 'OFFLINE_ERROR'].includes(data?.type)) return;
      state = data.status;
      failure = data.type === 'OFFLINE_ERROR' ? ({
        network: 'Соединение прервалось. Скачанные файлы сохранены. Когда появится интернет, нажмите «Продолжить загрузку».',
        storage: 'Не хватает места. Освободите место на устройстве и продолжите загрузку.',
        incomplete: 'Часть файлов не сохранилась. Нажмите «Продолжить загрузку», чтобы скачать недостающее.',
        auth: 'Не удалось получить материалы сайта. Откройте его с интернетом и повторите загрузку.',
        paused: ''
      }[data.code] ?? 'Загрузка остановилась. Повторите её: уже скачанные файлы сохранены.') : '';
      render();
    });
  }
  async function setup(force = false) {
    if (settingUp || (!force && registration?.installing &&
        registration.installing.state !== 'redundant')) return;
    settingUp = true;
    render();
    try {
      registration = await navigator.serviceWorker.register('sw.js', {scope: './', updateViaCache: 'none'});
      const watch = worker => {
        if (!worker) return;
        worker.addEventListener('statechange', () => {
          if (worker.state === 'installed' || worker.state === 'activated') {
            // Registration.waiting is assigned after the installed state event.
            setTimeout(() => { render(); refresh(); }, 0);
          }
          if (worker.state === 'redundant') {
            updateStatus = 'Подготовка обновления прервалась. Нажмите «Проверить обновление».';
            if (!registration.active) failure ||= 'Не удалось подготовить офлайн-режим. Проверьте интернет и нажмите «Повторить подготовку».';
            render();
          }
        });
      };
      watch(registration.installing);
      registration.addEventListener('updatefound', () => { watch(registration.installing); render(); });
      navigator.serviceWorker.ready.then(async () => { failure = ''; await refresh(); });
      await refresh();
      if (state?.resumeUpdate && !state.downloading && navigator.onLine) await request('RESUME_UPDATE');
      render();
    } catch (error) {
      failure ||= 'Не удалось подготовить офлайн-режим. Проверьте интернет и нажмите «Повторить подготовку».';
      render();
    } finally { settingUp = false; render(); }
  }
  render();
  if (supported) setup();
})();
