'use strict';
window.CockpitSurface = (() => {
const visual=window.COCKPIT_VISUAL;
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const controls=new Map(window.COCKPIT_DATA.controls.map(c=>[c.id,c]));
let viewport,scene,poses=[],scale=1,fitScale=1,tx=0,ty=0,observer,points=new Map(),gesture=null,suppressClick=false,currentPanel,lastW=0,lastH=0,logicalWidth=0,logicalHeight=0;
let displayMode='engine',lastSelected,lastMatches;
const spec=key=>{const p=visual.parts[key];return currentPanel!=='combined'&&p.detailClip?{...p,clip:p.detailClip}:p;};
const owner=id=>visual.parts[visual.hits.find(h=>h.id===id)?.part]?.panel||visual.unpictured[id]?.panel||controls.get(id)?.panel;
function layout(panel){
 const all=Object.entries(visual.parts).map(([key,p])=>({key,...p.pose,height:p.pose.width*p.clip[3]/p.clip[2]}));
 if(panel==='combined')return {...visual.layout,items:all.filter(p=>!visual.parts[p.key].detailOnly)};
 let items=all.filter(p=>visual.parts[p.key].panel===panel);
 if(panel==='mcp'||panel==='main'){
  const minX=Math.min(...items.map(p=>p.x)),minY=Math.min(...items.map(p=>p.y));
  items=items.map(p=>({...p,x:p.x-minX+25,y:p.y-minY+25}));
  return {width:Math.max(...items.map(p=>p.x+p.width))+25,height:Math.max(...items.map(p=>p.y+p.height))+25,items};
 }
 let y=25,maxW=0;
 items=items.map(p=>{const v=visual.parts[p.key],width=panel==='pedestal'?(p.key==='cdus'?800:p.key==='pedestal'?660:p.key==='throttle'?440:p.key==='fire'?600:300):700;const height=width*v.clip[3]/v.clip[2];const next={key:p.key,x:25,y,width,height};y+=height+30;maxW=Math.max(maxW,width);return next;});
 items.forEach(p=>p.x=(maxW-p.width)/2+25);
 return {width:maxW+50,height:y,items};
}
function hitClip(h){
 if(!['aft','overhead','mcp','glare-l','glare-r','main-l','main-c','main-r','main-lower','cdus','throttle','thrust-side','trim-cutout','fire','pedestal','stand-accessories'].includes(h.part))return '';
 if(h.polygon)return 'clip-path:polygon('+h.polygon.map(([x,y])=>((x-h.x)/h.w*100)+'% '+((y-h.y)/h.h*100)+'%').join(',')+');';
 if(h.shape==='circle')return 'border-radius:50%;clip-path:ellipse(50% 50% at 50% 50%);';
 if(h.shape==='frame'&&h.innerBox){
  const [x,y,xx,yy]=h.innerBox;
  const a=(x-h.x)/h.w*100,b=(y-h.y)/h.h*100,c=(xx-h.x)/h.w*100,d=(yy-h.y)/h.h*100;
  return `border-radius:0;clip-path:polygon(evenodd,0% 0%,100% 0%,100% 100%,0% 100%,0% 0%,${a}% ${b}%,${a}% ${d}%,${c}% ${d}%,${c}% ${b}%,${a}% ${b}%);`;
 }
 if(h.shape==='ring'&&h.innerBox){
  const [x,y,xx,yy]=h.innerBox;
  const ellipse=(rx,ry,cx,cy,reverse=false)=>Array.from({length:49},(_,i)=>{const a=(reverse?-1:1)*i/48*Math.PI*2;return (cx+rx*Math.cos(a))+'% '+(cy+ry*Math.sin(a))+'%';});
  const inside=ellipse((xx-x)/h.w*50,(yy-y)/h.h*50,((x+xx)/2-h.x)/h.w*100,((y+yy)/2-h.y)/h.h*100,true);
  return 'border-radius:50%;clip-path:polygon(evenodd,'+ellipse(50,50,50,50).concat(inside).join(',')+');';
 }
 if(h.part==='aft'&&h.shape==='ring'){
  const circle=(r,n,reverse=false)=>Array.from({length:n+1},(_,i)=>{const a=(reverse?-1:1)*i/n*Math.PI*2;return (50+r*Math.cos(a))+'% '+(50+r*Math.sin(a))+'%';});
  return 'clip-path:polygon(evenodd,'+circle(50,32).concat(circle(26,24,true)).join(',')+');';
 }
 return '';
}
function partHTML(pose,selected,matches){const p=spec(pose.key), [cx,cy,cw,ch]=p.clip;const height=pose.width*ch/cw;pose.height=height;
 const displayImages=(visual.displays||[]).filter(d=>d.part===pose.key&&(!d.mode||d.mode===displayMode)).map(d=>{const [x,y,w,h]=d.box;return `<img class="instrument-display" data-display="${esc(d.id)}" src="${esc(d.image)}" alt="${esc(d.name)} · пример индикации FCOM" draggable="false" style="left:${(x-cx)/cw*100}%;top:${(y-cy)/ch*100}%;width:${w/cw*100}%;height:${h/ch*100}%;${d.radius?`border-radius:${d.radius/w*100}% / ${d.radius/h*100}%;`:''}">`;}).join('');
 const hotspots=visual.hits.filter(h=>h.part===pose.key&&controls.has(h.id)&&(!h.mode||h.mode===displayMode)).map(h=>{const c=controls.get(h.id);return `<button class="hotspot control ${h.shape||''} ${h.id===selected?'selected':''} ${matches?matches.has(h.id)?'match':'dim':''}" data-control="${esc(h.id)}" data-hit-index="${visual.hits.indexOf(h)}" ${h.positionIndex!==undefined?`data-reference-position="${h.positionIndex}"`:''} style="left:${(h.x-cx)/cw*100}%;top:${(h.y-cy)/ch*100}%;width:${h.w/cw*100}%;height:${h.h/ch*100}%;${h.z?`z-index:${h.z};`:''}${h.field?'border-radius:0;':''}${hitClip(h)}" aria-label="${esc(c.label+' — '+c.ru)}" aria-pressed="${h.id===selected}" title="${esc(c.label+' · '+c.ru)}"></button>`;}).join('');
 return `<section class="visual-part" data-part="${pose.key}" style="left:${pose.x}px;top:${pose.y}px;width:${pose.width}px;height:${height}px;${p.mask?`clip-path:${p.mask};`:""}" aria-label="${esc(p.name)}"><img class="panel-photo" src="${p.image}" alt="Чертёж ${esc(p.name)} из FCOM S7 Boeing 737-800" draggable="false" style="width:${p.sourceWidth/cw*100}%;left:${-cx/cw*100}%;top:${-cy/ch*100}%">${displayImages}${currentPanel==='combined'?`<button class="part-open" data-panel="${p.panel}" aria-label="Увеличить ${esc(p.name)}" tabindex="-1"></button>`:''}${hotspots}<span class="part-caption">${esc(p.name)}</span></section>`;
}
function render(container,{panel,selected,matches,zones,refs}){
 observer?.disconnect();points.clear();gesture=null;currentPanel=panel;lastSelected=selected;lastMatches=matches;
 const l=layout(panel);poses=l.items;logicalWidth=l.width;logicalHeight=l.height;
 const variants=Object.entries(visual.unpictured).filter(([,v])=>panel==='combined'||v.panel===panel);
 container.innerHTML=`<section class="panel-shell physical-shell"><div class="panel-topline"><span>${panel==='combined'?'737–800 · ОБЩИЙ ВИД':'737–800 / '+esc(window.COCKPIT_DATA.panels.find(p=>p.id===panel)?.name.toUpperCase()||panel)}</span><button class="panel-original" data-fcom="${refs[0]}" data-sequence="${refs.join('|')}">Рисунок FCOM ↗</button></div>${['main','pedestal'].includes(panel)&&visual.displays?.length?`<div class="display-example-toolbar"><span>Примеры FCOM · нижний DU</span><button data-display-mode="engine" aria-pressed="${displayMode==='engine'}" class="${displayMode==='engine'?'active':''}">Двигатели</button><button data-display-mode="sys" aria-pressed="${displayMode==='sys'}" class="${displayMode==='sys'?'active':''}">Системы</button></div>`:''}${panel==='pedestal'?`<div class="part-tabs">${poses.map(p=>`<button data-focus-part="${p.key}">${esc(visual.parts[p.key].name)}</button>`).join('')}</div>`:''}<div class="viewport physical-viewport" id="viewport" aria-label="Интерактивная кабина. Перетаскивайте изображение для перемещения; Ctrl + колесо мыши или жест двумя пальцами меняет масштаб."><div id="cockpit-board" class="cockpit-scene ${zones?'zones-visible':''}" style="width:${l.width}px;height:${l.height}px">${poses.map(p=>partHTML(p,selected,matches)).join('')}</div><div class="canvas-hint">${panel==='combined'?'Нажмите на панель, чтобы открыть её крупнее':'Нажмите на элемент, чтобы открыть описание'}</div><div class="hover-label" aria-live="polite"></div></div><div class="panel-footline"><span class="vector-badge">Оригинал FCOM S7</span><button class="overview-link" data-panel="combined">⊞ Общий вид</button><div class="zoom-tools"><button data-zoom="out" aria-label="Уменьшить масштаб">−</button><output id="zoom-value"></output><button data-zoom="in" aria-label="Увеличить масштаб">+</button><button data-zoom="fit">Вписать</button></div></div></section>${variants.length?`<details class="variant-controls"><summary>${panel==='pedestal'?'Элементы вне показанного ракурса':'Другие варианты комплектации'} · ${variants.length}</summary><p>${panel==='pedestal'?'Эти органы описаны в FCOM, но не различимы на выбранных рисунках пульта.':'Эти элементы относятся к другим вариантам комплектации.'} Откройте карточку, чтобы прочитать описание и посмотреть исходный рисунок FCOM.</p>${variants.map(([id,v])=>`<div><button data-related="${id}">${esc(controls.get(id).label)} ↗</button><span>${esc(v.reason)}</span></div>`).join('')}</details>`:''}`;
 viewport=container.querySelector('#viewport');scene=container.querySelector('#cockpit-board');
 observer=new ResizeObserver(()=>{if(viewport.clientWidth!==lastW||viewport.clientHeight!==lastH)fit();});observer.observe(viewport);fit();bind();
}
function apply(){if(!scene)return;
 // Resize SVG images to the output dimensions. Never scale a composited bitmap.
 scene.style.width=logicalWidth*scale+'px';scene.style.height=logicalHeight*scale+'px';
 scene.style.transform=`translate(${tx}px,${ty}px)`;scene.dataset.scale=scale;
 for(const pose of poses){const el=scene.querySelector(`[data-part="${pose.key}"]`);el.style.left=pose.x*scale+'px';el.style.top=pose.y*scale+'px';el.style.width=pose.width*scale+'px';el.style.height=pose.height*scale+'px';}
 const out=document.querySelector('#zoom-value');if(out)out.textContent=Math.round(scale*100)+'%';
}
function fit(){if(!viewport||!scene?.isConnected)return;lastW=viewport.clientWidth;lastH=viewport.clientHeight;fitScale=Math.min((lastW-36)/logicalWidth,(lastH-36)/logicalHeight);scale=fitScale;tx=(lastW-logicalWidth*scale)/2;ty=(lastH-logicalHeight*scale)/2;apply();}
function zoomAt(next,x=viewport.clientWidth/2,y=viewport.clientHeight/2){next=Math.max(fitScale*.65,Math.min(8,next));const k=next/scale;tx=x-(x-tx)*k;ty=y-(y-ty)*k;scale=next;apply();}
function zoom(action){if(!viewport)return;if(action==='fit')fit();else if(action==='reset')zoomAt(1);else zoomAt(scale*(action==='in'?1.35:1/1.35));}
function bind(){
 viewport.addEventListener('wheel',e=>{e.preventDefault();if(e.ctrlKey||e.metaKey){const r=viewport.getBoundingClientRect();zoomAt(scale*Math.exp(-e.deltaY*.006),e.clientX-r.left,e.clientY-r.top);}else{tx-=e.deltaX;ty-=e.deltaY;apply();}},{passive:false});
 viewport.addEventListener('pointerdown',e=>{if(e.button!==0)return;points.set(e.pointerId,{x:e.clientX,y:e.clientY});if(points.size===1)gesture={startX:e.clientX,startY:e.clientY,tx,ty,moved:false};if(points.size===2){const [a,b]=[...points.values()];gesture={pinch:true,distance:Math.hypot(a.x-b.x,a.y-b.y),scale,tx,ty,midX:(a.x+b.x)/2,midY:(a.y+b.y)/2,moved:true};} });
 viewport.addEventListener('pointermove',e=>{
 const button=e.target.closest('[data-control]');if(!points.size){const label=viewport.querySelector('.hover-label');label.textContent=button?controls.get(button.dataset.control)?.label+' · '+controls.get(button.dataset.control)?.ru:'';return;}
 if(!points.has(e.pointerId)||!gesture)return;points.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(gesture.pinch&&points.size===2){const [a,b]=[...points.values()],r=viewport.getBoundingClientRect(),k=Math.hypot(a.x-b.x,a.y-b.y)/gesture.distance;scale=Math.max(fitScale*.65,Math.min(8,gesture.scale*k));const ratio=scale/gesture.scale;tx=(a.x+b.x)/2-r.left-(gesture.midX-r.left-gesture.tx)*ratio;ty=(a.y+b.y)/2-r.top-(gesture.midY-r.top-gesture.ty)*ratio;apply();}
 else if(!gesture.pinch){const dx=e.clientX-gesture.startX,dy=e.clientY-gesture.startY;if(Math.hypot(dx,dy)>5){gesture.moved=true;viewport.setPointerCapture(e.pointerId);viewport.classList.add('dragging');tx=gesture.tx+dx;ty=gesture.ty+dy;apply();}}
 });
 function end(e){if(!points.has(e.pointerId))return;if(gesture?.moved){suppressClick=true;setTimeout(()=>suppressClick=false,100);}points.delete(e.pointerId);viewport.classList.remove('dragging');if(points.size===1){const p=[...points.values()][0];gesture={startX:p.x,startY:p.y,tx,ty,moved:true};}else gesture=null;}
 viewport.addEventListener('pointerup',end);viewport.addEventListener('pointercancel',end);
 viewport.addEventListener('click',e=>{if(suppressClick){e.preventDefault();e.stopPropagation();}},{capture:true});
 viewport.addEventListener('pointerleave',()=>viewport.querySelector('.hover-label').textContent='');
 viewport.addEventListener('focusin',e=>{const b=e.target.closest('[data-control]');if(b&&!points.size)reveal(b.dataset.control,false,{hitIndex:Number(b.dataset.hitIndex)});});
}
function reveal(id,enlarge=true,{part,hitIndex}={}){if(!viewport||!scene?.isConnected)return;const h=visual.hits.find((h,i)=>h.id===id&&(part===undefined||h.part===part)&&(hitIndex===undefined||i===hitIndex)&&poses.some(p=>p.key===h.part)&&(!h.mode||h.mode===displayMode));if(!h)return;const pose=poses.find(p=>p.key===h.part),p=spec(h.part);const x=pose.x+(h.x+h.w/2-p.clip[0])/p.clip[2]*pose.width;const y=pose.y+(h.y+h.h/2-p.clip[1])/p.clip[2]*pose.width;
 if(enlarge)scale=Math.min(2.2,Math.max(scale,viewport.clientWidth/(pose.width*1.15)));const px=x*scale+tx,py=y*scale+ty;
 if(enlarge||px<25||px>viewport.clientWidth-25||py<25||py>viewport.clientHeight-25){tx=viewport.clientWidth/2-x*scale;ty=viewport.clientHeight/2-y*scale;apply();}
}
function focusPart(key){const p=poses.find(p=>p.key===key);if(!p)return;scale=Math.min((viewport.clientWidth-40)/p.width,(viewport.clientHeight-40)/p.height);tx=(viewport.clientWidth-p.width*scale)/2-p.x*scale;ty=(viewport.clientHeight-p.height*scale)/2-p.y*scale;apply();}
function toggleZones(show){scene?.classList.toggle('zones-visible',show);}
function variant(id){return visual.hits.find(h=>h.id===id&&h.variant)?.variant||visual.unpictured[id]?.reason;}
function setDisplayMode(mode){
 if(!['engine','sys'].includes(mode))return;
 displayMode=mode;
 const selected=scene?.querySelector('.hotspot.selected')?.dataset.control||lastSelected;
 for(const pose of poses){if(!(visual.displays||[]).some(d=>d.part===pose.key&&d.mode))continue;const element=scene?.querySelector('[data-part="'+pose.key+'"]');if(element)element.outerHTML=partHTML(pose,selected,lastMatches);}
 apply();
 document.querySelectorAll('[data-display-mode]').forEach(b=>{b.classList.toggle('active',b.dataset.displayMode===mode);b.setAttribute('aria-pressed',String(b.dataset.displayMode===mode));});
}
function getCamera(){return viewport&&scene?.isConnected?{panel:currentPanel,scale,tx,ty}:null;}
function restoreCamera(camera){if(camera?.panel!==currentPanel||![camera.scale,camera.tx,camera.ty].every(Number.isFinite)||camera.scale<=0)return;scale=camera.scale;tx=camera.tx;ty=camera.ty;apply();}
return {render,zoom,reveal,focusPart,toggleZones,owner,variant,setDisplayMode,getDisplayMode:()=>displayMode,getCamera,restoreCamera};
})();
